"""Final closed-form model used in the manuscript (2D MA region) + optimization algorithms.

Geometric quantities (Omega = Phi^{-1}, Phi = K^{1/2} Hbar^H Hbar K^{1/2} + N I, v = K^{1/2} Hbar^H gbar):
  mu_m = (1/Om_mm - N) * (1 - tr(Om) + [Om^2]_mm / Om_mm)          (product form, in [0, kappa_m N])
  c_m  = (|[Om v]_m|^2 + N [Om^2]_mm) / Om_mm                         (ratio of expectations)
  d    = (N - v^H Om v) * (1 - tr(Om))                                 (product form, in [0, N])
Rates:
  Rb_m = log2(1 + zeta_m p_m (N - M + mu_m))
  Re_m = log2(1 + p_m (kappa_e c_m + 1) / (q (kappa_e d + N - M - off) + sbar_e^2))   off = 0 (manuscript) or 1
"""
import numpy as np
from scipy.optimize import minimize
from cf import Sys, LAM, LN2


class Model(Sys):
    def __init__(self, *a, eve_off=0, **k):
        super().__init__(*a, **k)
        self.off = eve_off

    def geo(self, T):
        N, M = self.N, self.M
        Hb, gb = self.Hbar(T), self.gbar(T)
        S = Hb * np.sqrt(self.kappa)[None, :]
        Om = np.linalg.inv(S.conj().T @ S + N * np.eye(M))
        v = S.conj().T @ gb
        Om2 = Om @ Om
        omm = np.real(np.diag(Om)); o2 = np.real(np.diag(Om2)); tr = np.real(np.trace(Om))
        w = Om @ v
        mu = (1 / omm - N) * (1 - tr + o2 / omm)
        c = (np.abs(w) ** 2 + N * o2) / omm
        d = (N - np.real(np.conj(v) @ w)) * (1 - tr)
        return mu, c, d, Om, v

    def coeffs(self, T):
        """a_m, b_m, e, f of the power-allocation problem."""
        N, M = self.N, self.M
        mu, c, d, _, _ = self.geo(T)
        a = self.zeta * (N - M + mu)
        b = self.kappa_e * c + 1
        e = self.kappa_e * d + N - M - self.off
        return a, b, e, self.sbe2

    def F(self, T, p, q):
        a, b, e, f = self.coeffs(T)
        return float(np.sum(np.log2(1 + a * p) - np.log2(1 + b * p / (q * e + f))))

    def grad_n(self, T, p, q, n):
        N, M = self.N, self.M
        mu, c, d, Om, v = self.geo(T)
        kap, ke = self.kappa, self.kappa_e
        Kh = np.sqrt(kap)
        tn = T[n]
        bn = np.exp(-1j * 2 * np.pi / LAM * (self.Au.T @ tn))
        s = Kh * bn
        eph = np.exp(1j * 2 * np.pi / LAM * (tn @ self.ae))
        Om2 = Om @ Om
        omm = np.real(np.diag(Om)); o2 = np.real(np.diag(Om2)); tr = np.real(np.trace(Om))
        w = Om @ v
        vOv = np.real(np.conj(v) @ w)
        X = p * (ke * c + 1)
        Y = q * (ke * d + N - M - self.off) + self.sbe2
        g = np.zeros(2)
        for k in range(2):
            Dk = self.Au[k, :]
            sd = Kh * (-1j * 2 * np.pi / LAM) * Dk * bn
            vd = Kh * (1j * 2 * np.pi / LAM) * (self.ae[k] - Dk) * bn * eph
            Os, Osd = Om @ s, Om @ sd
            dOm = -(np.outer(Osd, Os.conj()) + np.outer(Os, Osd.conj()))
            domm = np.real(np.diag(dOm)); do2 = 2 * np.real(np.diag(Om @ dOm)); dtr = np.real(np.trace(dOm))
            # mu = (1/omm - N) * (1 - tr + o2/omm)
            f1 = 1 / omm - N; f2 = 1 - tr + o2 / omm
            df1 = -domm / omm ** 2
            df2 = -dtr + (do2 * omm - o2 * domm) / omm ** 2
            dmu = df1 * f2 + f1 * df2
            dw = dOm @ v + Om @ vd
            dc = (2 * np.real(np.conj(w) * dw) + N * do2) / omm - c * domm / omm
            dvOv = 2 * np.real(np.conj(v) @ (Om @ vd)) + np.real(np.conj(v) @ dOm @ v)
            dd = -dvOv * (1 - tr) - (N - vOv) * dtr
            dRb = self.zeta * p * dmu / ((1 + self.zeta * p * (N - M + mu)) * LN2)
            dRe = (p * ke * dc / (X + Y) - X * q * ke * dd / (Y * (X + Y))) / LN2
            g[k] = np.sum(dRb - dRe)
        return g

    # ------------------------------------------------------------------
    # Power allocation: secrecy water-filling for fixed q + 1D search over q
    # ------------------------------------------------------------------
    @staticmethod
    def wf(a, bp, PI):
        """max sum log2(1+a p) - log2(1+bp p)  s.t. sum p <= PI, p >= 0."""
        act = a > bp
        if PI <= 0 or not np.any(act):
            return np.zeros_like(a)

        def pnu(nu):
            D = (a - bp) ** 2 + 4 * a * bp * (a - bp) / (nu * LN2)
            pp = 2 * ((a - bp) / (nu * LN2) - 1) / (np.sqrt(np.maximum(D, 0)) + a + bp)
            return np.where(act, np.maximum(pp, 0), 0.0)
        lo, hi = 1e-12, np.max((a - bp)[act]) / LN2
        for _ in range(200):
            mid = np.sqrt(lo * hi)
            if np.sum(pnu(mid)) > PI:
                lo = mid
            else:
                hi = mid
        return pnu(hi)

    def power_opt(self, T, grid=None, refine=True):
        a, b, e, f = self.coeffs(T)
        N, M = self.N, self.M
        qmax = self.P / (N - M)

        def G(q):
            p = self.wf(a, b / (q * e + f), self.P - (N - M) * q)
            return float(np.sum(np.log2(1 + a * p) - np.log2(1 + b * p / (q * e + f)))), p
        grid = np.linspace(0, qmax, 41) if grid is None else grid
        vals = [G(q)[0] for q in grid]
        i = int(np.argmax(vals))
        lo, hi = grid[max(i - 1, 0)], grid[min(i + 1, len(grid) - 1)]
        if refine:  # golden-section on the bracket around the best grid point
            gr = (np.sqrt(5) - 1) / 2
            x1, x2 = hi - gr * (hi - lo), lo + gr * (hi - lo)
            f1, f2 = G(x1)[0], G(x2)[0]
            for _ in range(40):
                if f1 > f2:
                    hi, x2, f2 = x2, x1, f1; x1 = hi - gr * (hi - lo); f1 = G(x1)[0]
                else:
                    lo, x1, f1 = x1, x2, f2; x2 = lo + gr * (hi - lo); f2 = G(x2)[0]
            q = (lo + hi) / 2
        else:
            q = grid[i]
        val, p = G(q)
        return p, q, val, (grid, vals)

    # ------------------------------------------------------------------
    # Antenna position optimization: element-wise MM (quadratic minorizer) with backtracking
    # ------------------------------------------------------------------
    def _subproblem(self, T, n, z):
        """min ||t - z||^2 s.t. |x|,|y| <= A/2 and linearized min-distance constraints."""
        tn = T[n]; A2 = self.A / 2
        cons = []
        for i in range(self.N):
            if i == n:
                continue
            dvec = tn - T[i]
            c0 = np.dot(dvec, dvec) - self.Dmin ** 2
            cons.append({'type': 'ineq', 'fun': (lambda t, dvec=dvec, c0=c0: c0 + 2 * dvec @ (t - tn)),
                         'jac': (lambda t, dvec=dvec: 2 * dvec)})
        z0 = np.clip(z, -A2, A2)
        ok = all(cc['fun'](z0) >= -1e-12 for cc in cons)
        if ok:
            return z0
        res = minimize(lambda t: np.sum((t - z) ** 2), tn, jac=lambda t: 2 * (t - z), method='SLSQP',
                       bounds=[(-A2, A2), (-A2, A2)], constraints=cons, options={'ftol': 1e-12, 'maxiter': 200})
        return res.x

    def position_step(self, T, p, q, delta0=1.0):
        T = T.copy()
        for n in range(self.N):
            g = self.grad_n(T, p, q, n)
            F0 = self.F(T, p, q)
            delta = delta0
            for _ in range(60):
                tnew = self._subproblem(T, n, T[n] + g / delta)
                Tn = T.copy(); Tn[n] = tnew
                sur = F0 + g @ (tnew - T[n]) - delta / 2 * np.sum((tnew - T[n]) ** 2)
                if self.F(Tn, p, q) >= sur - 1e-12:
                    break
                delta *= 2
            T = Tn if self.F(Tn, p, q) >= F0 else T
        return T

    def ao(self, T0, iters=100, tol=1e-5, verbose=False):
        T = T0.copy()
        p, q, val, _ = self.power_opt(T)
        hist = [self.F(T, p, q)]
        for it in range(iters):
            T = self.position_step(T, p, q)
            p2, q2, _, _ = self.power_opt(T)
            if self.F(T, p2, q2) >= self.F(T, p, q):
                p, q = p2, q2
            hist.append(self.F(T, p, q))
            if verbose:
                print(it, hist[-1])
            if abs(hist[-1] - hist[-2]) < tol * max(1, abs(hist[-1])):
                break
        return T, p, q, hist

    def rand_feasible(self, rng):
        pts = []
        while len(pts) < self.N:
            cpt = rng.uniform(-self.A / 2, self.A / 2, 2)
            if all(np.linalg.norm(cpt - qq) >= self.Dmin for qq in pts):
                pts.append(cpt)
        return np.array(pts)
