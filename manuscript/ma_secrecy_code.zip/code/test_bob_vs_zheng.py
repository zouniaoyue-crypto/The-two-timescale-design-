"""Bob ergodic rate: proposed approximation (N-M+mu) vs the ZF bound of Zheng et al. (N-M)/(N Om_mm), against Monte Carlo."""
import numpy as np
from model import Model
rng = np.random.default_rng(3)
rows = []
for trial in range(120):
    M = int(rng.integers(2, 5)); N = M + int(rng.integers(1, 4))
    th = rng.uniform(-np.pi/3, np.pi/3, M); ph = rng.uniform(-np.pi/3, np.pi/3, M)
    kdb = rng.choice([-100, 0, 5, 10, 20]); kap = 10 ** (kdb / 10)
    PdB = rng.choice([0, 10, 20])
    s = Model(N, M, th, ph, 0.1, 0.2, kap, kap, PdB, A=3.0)
    T = s.rand_feasible(rng)
    p = np.full(M, s.P / M); q = 0.0
    Rb_mc, _ = s.mc(T, p, q, S=20000, seed=trial)
    mu, c, d, Om, v = s.geo(T)
    omm = np.real(np.diag(Om))
    R_prop = np.log2(1 + s.zeta * p * (N - M + mu))
    R_zh = np.log2(1 + s.zeta * p * (N - M) / (N * omm))
    rows.append((kdb, np.mean(R_prop - Rb_mc), np.mean(np.abs(R_prop - Rb_mc)), np.mean(R_zh - Rb_mc), np.mean(np.abs(R_zh - Rb_mc))))
r = np.array(rows)
for kdb in [-100, 0, 5, 10, 20]:
    sel = r[:, 0] == kdb
    if sel.any():
        print('kappa %4s dB: proposed bias %+.3f |err| %.3f   Zheng-bound bias %+.3f |err| %.3f  (bits/user, %d drops)' % (
            'Ray' if kdb == -100 else kdb, *r[sel, 1:].mean(0), sel.sum()))
print('overall: proposed |err| %.3f, Zheng |err| %.3f' % (r[:, 2].mean(), r[:, 4].mean()))
