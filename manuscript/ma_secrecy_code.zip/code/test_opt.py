import numpy as np, time
from scipy.optimize import minimize
from model import Model
from cf import essr, LN2

rng = np.random.default_rng(7)

# ---------- 1) gradient check for the final (product-form) model ----------
worst = 0
for trial in range(15):
    M = int(rng.integers(2, 5)); N = M + int(rng.integers(1, 4))
    th = rng.uniform(-1, 1, M); ph = rng.uniform(-1, 1, M)
    s = Model(N, M, th, ph, rng.uniform(-1, 1), rng.uniform(-1, 1), 10 ** rng.uniform(-1, 2, M), 10 ** rng.uniform(-1, 2), 20, A=3.0)
    T = s.rand_feasible(rng)
    p = rng.uniform(.1, 1, M) * s.P / M; q = rng.uniform(.1, 1) * s.P / (N - M)
    for n in range(N):
        ga = s.grad_n(T, p, q, n); gn = np.zeros(2)
        for k in range(2):
            Tp = T.copy(); Tp[n, k] += 1e-6; Tm = T.copy(); Tm[n, k] -= 1e-6
            gn[k] = (s.F(Tp, p, q) - s.F(Tm, p, q)) / 2e-6
        worst = max(worst, np.max(np.abs(ga - gn)) / (np.max(np.abs(gn)) + 1e-9))
print('final model: max relative gradient error =', worst)

# ---------- 2) water-filling vs generic solver ----------
worst = 0
for trial in range(30):
    M = int(rng.integers(1, 5))
    a = 10 ** rng.uniform(-1, 2, M); bp = a * rng.uniform(0, 1.5, M); PI = 10 ** rng.uniform(-1, 2)
    p_wf = Model.wf(a, bp, PI)
    obj = lambda p: -np.sum(np.log2(1 + a * p) - np.log2(1 + bp * p))
    best = np.inf
    for _ in range(5):
        x0 = rng.dirichlet(np.ones(M)) * PI
        r = minimize(obj, x0, method='SLSQP', bounds=[(0, PI)] * M,
                     constraints=[{'type': 'ineq', 'fun': lambda p: PI - np.sum(p)}], options={'ftol': 1e-14, 'maxiter': 500})
        best = min(best, r.fun)
    worst = max(worst, obj(p_wf) - best)
print('water-filling vs SLSQP: max (obj_wf - obj_best) =', worst, '(<=0 means wf is at least as good)')

# ---------- 3) AO monotonicity + MC gains in a 2D scenario ----------
for eve_off in [0]:  # 0 = manuscript model
    print('--- Eve approximation offset', eve_off, '---')
    res = []
    t0 = time.time()
    for drop in range(12):
        M, N = 3, 6
        th = rng.uniform(-np.pi / 3, np.pi / 3, M); ph = rng.uniform(-np.pi / 3, np.pi / 3, M)
        k0 = rng.integers(M)
        s = Model(N, M, th, ph, th[k0] + rng.uniform(-.15, .15), ph[k0] + rng.uniform(-.15, .15), 10.0, 10.0, 20,
                  A=3.0, eve_off=eve_off)
        Tf = s.upa(2, 3)
        # FPA: optimized power
        pf, qf, _, _ = s.power_opt(Tf)
        Rb, Re = s.mc(Tf, pf, qf, S=8000, seed=drop)
        fpa = essr(Rb, Re)
        # MA: AO from FPA and 3 random inits
        best = (-np.inf, None)
        for init in [Tf] + [s.rand_feasible(rng) for _ in range(3)]:
            T, p, q, hist = s.ao(init, iters=60)
            assert all(np.diff(hist) >= -1e-9), 'non-monotone'
            if hist[-1] > best[0]:
                best = (hist[-1], (T, p, q))
        T, p, q = best[1]
        Rb, Re = s.mc(T, p, q, S=8000, seed=drop)
        ma = essr(Rb, Re)
        res.append((fpa, ma, best[0]))
        print(f'drop {drop}: FPA {fpa:.2f}  MA {ma:.2f}  (surrogate {best[0]:.2f})  gain {100*(ma/fpa-1):.1f}%', flush=True)
    r = np.array(res)
    print('mean FPA %.2f  MA %.2f  mean gain %.1f%%  surrogate-vs-MC mean err %.2f  time %.0fs' % (
        r[:, 0].mean(), r[:, 1].mean(), 100 * np.mean(r[:, 1] / r[:, 0] - 1), np.mean(np.abs(r[:, 2] - r[:, 1])), time.time() - t0))
