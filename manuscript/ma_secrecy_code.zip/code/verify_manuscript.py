"""Literal re-implementation of the manuscript equations, checked against model.py, finite differences and Monte Carlo."""
import numpy as np
from scipy.special import hyp1f1
from model import Model
from cf import LAM, LN2
rng = np.random.default_rng(2026)
res = {}
def rec(k, v): res[k] = max(res.get(k, 0.0), float(v))

for trial in range(40):
    M = int(rng.integers(2, 5)); N = M + int(rng.integers(1, 4))
    th = rng.uniform(-1, 1, M); ph = rng.uniform(-1, 1, M)
    kap = 10 ** rng.uniform(-1, 2, M); ke = 10 ** rng.uniform(-1, 2)
    s = Model(N, M, th, ph, rng.uniform(-1, 1), rng.uniform(-1, 1), kap, ke, 20, A=3.0)
    T = s.rand_feasible(rng)
    Hb, gb = s.Hbar(T), s.gbar(T); K = np.diag(kap); Kh = np.sqrt(K)
    Phi = Kh @ Hb.conj().T @ Hb @ Kh + N * np.eye(M); Om = np.linalg.inv(Phi)       # (25)
    v = Kh @ Hb.conj().T @ gb                                                         # (35)
    mu_m, c_m, d_m, _, _ = s.geo(T)
    # (23),(24): direct per-user form  mu = kappa_m * epsbar_m
    mu_dir = np.zeros(M); trPm = np.zeros(M)
    for m in range(M):
        idx = [j for j in range(M) if j != m]
        Am = Hb[:, idx] @ np.diag(np.sqrt(kap[idx]))
        Phim = Am.conj().T @ Am + N * np.eye(M - 1)
        Pinv = np.linalg.inv(Phim); trPm[m] = np.real(np.trace(Pinv))
        h = Hb[:, m]
        eps = (N - np.real(h.conj() @ Am @ Pinv @ Am.conj().T @ h)) * (1 - trPm[m])
        mu_dir[m] = kap[m] * eps
        # (26) Schur complement
        rec('(26) schur', abs(np.real(Om[m, m]) - 1 / (N * (kap[m] + 1) - kap[m] * np.real(h.conj() @ Am @ Pinv @ Am.conj().T @ h))))
        # (27)
        P27 = Om[np.ix_(idx, idx)] - np.outer(Om[idx, m], Om[m, idx]) / Om[m, m]
        rec('(27) block inverse', np.max(np.abs(P27 - Pinv)))
    omm = np.real(np.diag(Om)); o2 = np.real(np.diag(Om @ Om)); tr = np.real(np.trace(Om))
    mu28 = (1 / omm - N) * (1 - tr + o2 / omm)                                        # (28)
    rec('(28) vs (24)', np.max(np.abs(mu28 - mu_dir)) / (1 + np.max(mu_dir)))
    rec('(28) vs model', np.max(np.abs(mu28 - mu_m)))
    rec('0<=mu<=kN violation', max(0, -np.min(mu28), np.max(mu28 - kap * N)))
    # (30) comparison identity with Zheng's bound
    lhs = N - M + mu28 - (N - M) / (N * omm)
    rhs = (1 / omm - N) * (M / N - trPm)
    rec('(30) identity', np.max(np.abs(lhs - rhs)) / (1 + np.max(np.abs(lhs))))
    rec('(30) negativity', max(0, -np.min(rhs)))
    # Sigma(t) of Zheng (38)-(39) equals (1/N)(K+I)^{-1/2} Phi (K+I)^{-1/2}
    L1 = np.linalg.inv(K + np.eye(M)); L2 = np.sqrt(K @ L1)
    Sig = L1 + L2 @ Hb.conj().T @ Hb @ L2 / N
    D = np.diag(1 / np.sqrt(kap + 1))
    rec('Sigma identity', np.max(np.abs(Sig - D @ Phi @ D / N)))
    # (37),(38)
    c37 = (np.abs(Om @ v) ** 2 + N * o2) / omm
    d38 = (N - np.real(v.conj() @ Om @ v)) * (1 - tr)
    rec('(37) vs model', np.max(np.abs(c37 - c_m))); rec('(38) vs model', abs(d38 - d_m))
    # (57)-(59): rank-one structure and Sherman-Morrison, for every n
    for n in range(N):
        b = [np.exp(-1j * 2 * np.pi / LAM * (s.Au.T @ T[i])) for i in range(N)]    # (bn)
        k = [Kh @ bi for bi in b]
        Gam = sum(np.outer(k[i], k[i].conj()) for i in range(N) if i != n) + N * np.eye(M)
        r = sum(k[i] * np.exp(1j * 2 * np.pi / LAM * T[i] @ s.ae) for i in range(N) if i != n)
        rec('(57)', np.max(np.abs(Gam + np.outer(k[n], k[n].conj()) - Phi)))
        rec('(58)', np.max(np.abs(r + k[n] * np.exp(1j * 2 * np.pi / LAM * T[n] @ s.ae) - v)))
        Gi = np.linalg.inv(Gam)
        OmSM = Gi - Gi @ np.outer(k[n], k[n].conj()) @ Gi / (1 + np.real(k[n].conj() @ Gi @ k[n]))
        rec('(59) Sherman-Morrison', np.max(np.abs(OmSM - Om)))
    # (60)-(63) and Appendix (69)-(76), literal
    p = rng.uniform(.1, 1, M) * s.P / M; q = rng.uniform(.1, 1) * s.P / (N - M)
    eta = s.zeta * (N - M + mu28); xi = ke * c37 + 1; psi = ke * d38 + N - M        # (46)
    Lam = xi * p; Ups = q * psi + s.sbe2
    for n in range(N):
        for ui in range(2):
            Du = np.diag(s.Au[ui]); aeu = s.ae[ui]
            kn = Kh @ np.exp(-1j * 2 * np.pi / LAM * (s.Au.T @ T[n]))
            kd = -1j * 2 * np.pi / LAM * Du @ kn                                       # (60)
            vd = 1j * 2 * np.pi / LAM * (aeu * np.eye(M) - Du) @ kn * np.exp(1j * 2 * np.pi / LAM * T[n] @ s.ae)  # (61)
            Omd = -Om @ (np.outer(kd, kn.conj()) + np.outer(kn, kd.conj())) @ Om       # (62)
            wd = -2 * np.real((Om @ kd) * np.conj(Om @ kn))                            # (69)
            od = -2 * np.real((Om @ Om @ kd) * np.conj(Om @ kn) + (Om @ Om @ kn) * np.conj(Om @ kd))  # (70)
            taud = -2 * np.real(kn.conj() @ Om @ Om @ kd)                              # (71)
            rec('(69) vs diag', np.max(np.abs(wd - np.real(np.diag(Omd)))))
            rec('(70) vs 2Re', np.max(np.abs(od - 2 * np.real(np.diag(Om @ Omd)))))
            rec('(71) vs trace', abs(taud - np.real(np.trace(Omd))))
            mud = -wd / omm ** 2 * (1 - tr + o2 / omm) + (1 / omm - N) * ((od * omm - o2 * wd) / omm ** 2 - taud)  # (72)
            vt = Om @ v
            vtd = -Om @ kd * (kn.conj() @ vt) - Om @ kn * (kd.conj() @ vt) + Om @ vd    # (73)
            cd = (2 * np.real(np.conj(vt) * vtd) + N * od - c37 * wd) / omm            # (74)
            dvOv = 2 * np.real(vt.conj() @ vd) - 2 * np.real((vt.conj() @ kd) * (kn.conj() @ vt))  # (75)
            dd = -dvOv * (1 - tr) - (N - np.real(v.conj() @ Om @ v)) * taud             # (76)
            dF = np.sum(s.zeta * p * mud / (1 + eta * p) - ke * p * cd / (Lam + Ups) + ke * q * Lam * dd / (Ups * (Lam + Ups))) / LN2  # (63)
            Tp = T.copy(); Tp[n, ui] += 1e-6; Tm = T.copy(); Tm[n, ui] -= 1e-6
            fd = (s.F(Tp, p, q) - s.F(Tm, p, q)) / 2e-6
            rec('(63)+(69)-(76) vs finite diff (rel)', abs(dF - fd) / (abs(fd) + 1e-3))
    # (47a) objective equals model.F
    Fman = np.sum(np.log2(1 + eta * p) - np.log2(1 + xi * p / (q * psi + s.sbe2)))
    rec('(47a) vs model.F', abs(Fman - s.F(T, p, q)))
    # (54) secrecy water-filling: KKT stationarity at the returned solution
    thq = xi / (q * psi + s.sbe2); PI = s.P - (N - M) * q
    pw = Model.wf(eta, thq, PI)
    act = pw > 1e-9
    if act.any():
        fprime = (eta - thq) / (LN2 * (1 + eta * pw) * (1 + thq * pw))               # (50)
        nu = np.mean(fprime[act])
        rec('(54) KKT: spread of f\'(p) over active users', np.ptp(fprime[act]) / nu)
        rec('(54) KKT: inactive users have f\'(0)<=nu', max(0, np.max(np.where(~act, (eta - thq) / LN2 - nu, -1)) / nu))
        rec('(54) power budget', abs(pw.sum() - PI) / PI)
        # closed form (54) reproduces the same p for this nu
        Dl = (eta - thq) ** 2 + 4 * eta * thq * (eta - thq) / (nu * LN2)
        p54 = np.maximum(2 * ((eta - thq) / (nu * LN2) - 1) / (np.sqrt(np.maximum(Dl, 0)) + eta + thq), 0) * (eta > thq)
        rec('(54) closed form vs solver', np.max(np.abs(p54 - pw)) / PI)
    # (linc) equivalence with (65)
    for n in range(N):
        for i in range(N):
            if i == n: continue
            dni = T[n] - T[i]; z = rng.uniform(-1.5, 1.5, 2)
            lhs65 = dni @ dni + 2 * dni @ (z - T[n]) - s.Dmin ** 2
            lin = dni @ z - (dni @ T[n] + (s.Dmin ** 2 - dni @ dni) / 2)
            rec('(linc) == (65)', abs(lhs65 - 2 * lin))

# M = 1 special case (42)-(43)
for trial in range(10):
    N = int(rng.integers(2, 7)); k1 = 10 ** rng.uniform(-1, 2)
    s = Model(N, 1, [rng.uniform(-1, 1)], [rng.uniform(-1, 1)], rng.uniform(-1, 1), rng.uniform(-1, 1), k1, 3.0, 20, A=3.0)
    T = s.rand_feasible(rng); mu, c, d, _, _ = s.geo(T)
    corr = abs(s.Hbar(T)[:, 0].conj() @ s.gbar(T)) ** 2
    rec('M=1 mu=kN', abs(mu[0] - k1 * N)); rec('(42)', abs(c[0] - (k1 * corr / N + 1) / (k1 + 1)))
    rec('(43)', abs(d - (N - k1 * corr / (N * (k1 + 1))) * (1 - 1 / (N * (k1 + 1)))))

# (44)-(45): high-SNR expansion and alpha*
for trial in range(10):
    M = 3; N = 6
    s = Model(N, M, rng.uniform(-1, 1, M), rng.uniform(-1, 1, M), rng.uniform(-1, 1), rng.uniform(-1, 1), 10.0, 10.0, 90, A=3.0)
    T = s.rand_feasible(rng); mu, c, d, _, _ = s.geo(T); a = rng.uniform(.2, .8)
    p = np.full(M, a * s.P / M); q = (1 - a) * s.P / (N - M)
    Km = (N - M) / M * (s.kappa_e * c + 1) / (s.kappa_e * d + N - M)
    exact = np.log2(1 + s.zeta * p * (N - M + mu)) - np.log2(1 + p * (s.kappa_e * c + 1) / (q * (s.kappa_e * d + N - M) + s.sbe2))
    asym = np.log2(a * s.P * s.zeta * (N - M + mu) / M) - np.log2(1 + a * Km / (1 - a))
    rec('(44) high-SNR expansion @P=90dB', np.max(np.abs(exact - asym)))
for Kc in [0.1, 0.5, 1.0, 3.0, 20.0]:
    al = np.linspace(1e-4, 1 - 1e-4, 200001)
    g = np.log(al) + np.log(1 - al) - np.log(1 + al * (Kc - 1))
    rec('(45) alpha*', abs(al[np.argmax(g)] - 1 / (1 + np.sqrt(Kc))))

# (18)-(19): inverse moment of the noncentral chi-square
for L1 in [1, 2, 4]:          # L1 = N - M
    for z in [0.0, 1.0, 10.0, 100.0]:
        S = 400000
        X = np.sum(np.abs(np.sqrt(z / (L1 + 1)) + (rng.standard_normal((S, L1 + 1)) + 1j * rng.standard_normal((S, L1 + 1))) / np.sqrt(2)) ** 2, axis=1)
        mc = np.mean(1 / X); cf = hyp1f1(1, L1 + 1, -z) / L1
        rec('(18) Kummer vs MC (rel)', abs(mc - cf) / cf)
        print(f'N-M={L1} z={z:6.1f}: 1/E[1/X]={1/cf:8.3f}  approx (19)={L1+z:8.3f}  rel.err={(L1+z)*cf-1:+.3f}')

# (22): residual approximation vs Monte Carlo, bounds and extreme cases
worst = 0
for trial in range(30):
    Nn = int(rng.integers(3, 8)); k = int(rng.integers(1, Nn))
    A0 = np.exp(1j * rng.uniform(0, 2 * np.pi, (Nn, k))); f = np.exp(1j * rng.uniform(0, 2 * np.pi, Nn))
    for sc in [0.0, 1.0, 3.0, 30.0]:
        A = sc * A0; PhiA = A.conj().T @ A + Nn * np.eye(k); Pi = np.linalg.inv(PhiA)
        appx = (np.real(f.conj() @ f) - np.real(f.conj() @ A @ Pi @ A.conj().T @ f)) * (1 - np.real(np.trace(Pi)))
        S = 20000
        W = (rng.standard_normal((S, Nn, k)) + 1j * rng.standard_normal((S, Nn, k))) / np.sqrt(2)
        F = A[None] + W
        Q, _ = np.linalg.qr(F)
        proj = np.einsum('snk,n->sk', Q.conj(), f)
        exact = np.mean(np.real(f.conj() @ f) - np.sum(np.abs(proj) ** 2, axis=1))
        rec('(22) bounds violation', max(0, -appx, appx - Nn))
        if sc == 0.0: rec('(22) exact at A=0 (MC noise)', abs(appx - exact) / Nn)
        if sc == 30.0: rec('(22) LoS-dominant (MC)', abs(appx - exact) / Nn)
        worst = max(worst, abs(appx - exact) / Nn)
print('(22) worst relative error over all scales (fraction of ||f||^2): %.3f' % worst)
print()
for k_, v_ in res.items():
    print('%-48s %.2e' % (k_, v_))
