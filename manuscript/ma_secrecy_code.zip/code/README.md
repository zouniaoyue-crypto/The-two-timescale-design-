# 推导核验与算法代码（对应 main.tex）

- `model.py`：稿件中的闭式模型与算法——μ_m (28)、c̄_m (37)、d̄ (38)，速率 (29)(39)，
  目标函数 (47a)，解析梯度 (65)/(72)–(76)，保密注水 (54) + q 的一维搜索（算法1），
  逐天线 MM 位置更新 + 回溯 + 线性化最小间距约束（算法2）。
- `cf.py`：系统参数、LoS 导向矢量、蒙特卡洛真值 `Sys.mc`（ZF + 零空间 AN，Eve 最坏情况消除他用户信号）。
- `verify_manuscript.py`：逐式照抄稿件公式，与 model.py、有限差分、蒙特卡洛对比（约 2–3 分钟）。
- `test_bob_vs_zheng.py`：式 (29) 与 Zheng 等 [3, Eq. (37)] 下界的精度对比（蒙特卡洛）。
- `test_opt.py`：AO 单调性与 MA 相对 FPA 的增益（12 个随机场景，较慢）。

运行：`python3 verify_manuscript.py`（需要 numpy、scipy）。
