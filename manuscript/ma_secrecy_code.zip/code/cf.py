"""Base system class: geometry, Monte Carlo ground truth (Sys.mc) and helpers.

NOTE: Sys.geo / Sys.rates / Sys.grad_n implement an earlier first-order variant and are kept
only for comparison. The manuscript model (product forms (28), (37), (38), rates (29), (39),
gradient (65)/(72)-(76), Algorithms 1-2) is implemented in model.py (class Model)."""
import numpy as np

LN2 = np.log(2.0)
LAM = 1.0


def dirvec(theta, phi):
    return np.array([np.cos(theta) * np.sin(phi), np.sin(theta)])


class Sys:
    def __init__(self, N, M, th, ph, th_e, ph_e, kappa, kappa_e, P_dBm_over_noise, beta=None, beta_e=1.0,
                 s2=1.0, s2e=1.0, A=3.0, Dmin=0.5):
        self.N, self.M = N, M
        self.Au = np.stack([dirvec(t, p) for t, p in zip(th, ph)], axis=1)  # 2 x M
        self.ae = dirvec(th_e, ph_e)
        self.kappa = np.full(M, float(kappa)) if np.isscalar(kappa) else np.asarray(kappa, float)
        self.kappa_e = float(kappa_e)
        self.beta = np.ones(M) if beta is None else np.asarray(beta, float)
        self.beta_e = float(beta_e)
        self.P = 10 ** (P_dBm_over_noise / 10)
        self.s2, self.s2e = s2, s2e
        self.A, self.Dmin = A, Dmin
        self.zeta = self.beta / ((self.kappa + 1) * self.s2)
        self.sbe2 = (self.kappa_e + 1) * self.s2e / self.beta_e

    # ---------------- LoS quantities ----------------
    def Hbar(self, T):
        return np.exp(1j * 2 * np.pi / LAM * (T @ self.Au))           # N x M

    def gbar(self, T):
        return np.exp(1j * 2 * np.pi / LAM * (T @ self.ae))           # N

    def geo(self, T):
        """mu (M,), c (M,), d, plus Omega and v."""
        N, M = self.N, self.M
        Hb, gb = self.Hbar(T), self.gbar(T)
        Kh = np.sqrt(self.kappa)
        S = Hb * Kh[None, :]                                            # N x M  (= Hbar K^{1/2})
        Phi = S.conj().T @ S + N * np.eye(M)
        Om = np.linalg.inv(Phi)
        v = S.conj().T @ gb
        Om2 = Om @ Om
        omm = np.real(np.diag(Om))
        o2mm = np.real(np.diag(Om2))
        trO = np.real(np.trace(Om))
        mu = 1.0 / omm - N - self.kappa * N * (trO - o2mm / omm)
        w = Om @ v
        c = (np.abs(w) ** 2 + N * o2mm) / omm
        d = N - np.real(np.conj(v) @ w) - N * trO
        return mu, c, d, Om, v

    # ---------------- approximate rates ----------------
    def rates(self, T, p, q):
        N, M = self.N, self.M
        mu, c, d, _, _ = self.geo(T)
        Rb = np.log2(1 + self.zeta * p * (N - M + mu))
        Re = np.log2(1 + p * (self.kappa_e * c + 1) / (q * (self.kappa_e * d + N - M - 1) + self.sbe2))
        return Rb, Re

    def F(self, T, p, q):
        Rb, Re = self.rates(T, p, q)
        return float(np.sum(Rb - Re))

    # ---------------- analytic gradient w.r.t. t_n ----------------
    def grad_n(self, T, p, q, n):
        """Returns [dF/dx_n, dF/dy_n] using the closed-form expressions of the manuscript."""
        N, M = self.N, self.M
        mu, c, d, Om, v = self.geo(T)
        kap, ke = self.kappa, self.kappa_e
        Kh = np.sqrt(kap)
        tn = T[n]
        b = np.exp(-1j * 2 * np.pi / LAM * (self.Au.T @ tn))          # b_n(t_n) in C^M (conj of row n of Hbar)
        s = Kh * b                                                      # s_n = K^{1/2} b_n
        eph = np.exp(1j * 2 * np.pi / LAM * (tn @ self.ae))             # e^{j 2pi/lam t_n^T a_e}
        Om2 = Om @ Om
        omm = np.real(np.diag(Om)); o2mm = np.real(np.diag(Om2)); trO = np.real(np.trace(Om))
        w = Om @ v
        Xm = p * (ke * c + 1)
        Y = q * (ke * d + N - M - 1) + self.sbe2
        g = np.zeros(2)
        for k in range(2):  # k=0: x_n, k=1: y_n
            Dk = self.Au[k, :]                                          # a_{i,x} or a_{i,y}
            aek = self.ae[k]
            sd = Kh * (-1j * 2 * np.pi / LAM) * Dk * b                  # s_dot = K^{1/2} d b_n / d x
            vd = Kh * (1j * 2 * np.pi / LAM) * (aek - Dk) * b * eph    # d v / d x
            # dPhi = sd s^H + s sd^H ;  dOm = -Om dPhi Om
            Os, Osd = Om @ s, Om @ sd
            dOm = -(np.outer(Osd, Os.conj()) + np.outer(Os, Osd.conj()))
            domm = np.real(np.diag(dOm))
            do2mm = 2 * np.real(np.diag(Om @ dOm))
            dtr = np.real(np.trace(dOm))
            dmu = -domm / omm ** 2 - kap * N * (dtr - (do2mm * omm - o2mm * domm) / omm ** 2)
            dw = dOm @ v + Om @ vd
            dc = (2 * np.real(np.conj(w) * dw) + N * do2mm) / omm - c * domm / omm
            dd = -2 * np.real(np.conj(v) @ (Om @ vd)) - np.real(np.conj(v) @ dOm @ v) - N * dtr
            dRb = self.zeta * p * dmu / ((1 + self.zeta * p * (N - M + mu)) * LN2)
            dRe = (p * ke * dc / (Xm + Y) - Xm * q * ke * dd / (Y * (Xm + Y))) / LN2
            g[k] = np.sum(dRb - dRe)
        return g

    # ---------------- Monte Carlo (exact ergodic rates) ----------------
    def mc(self, T, p, q, S=20000, seed=1, scheme='S1'):
        rng = np.random.default_rng(seed)
        N, M = self.N, self.M
        Hb, gb = self.Hbar(T), self.gbar(T)
        kap, be, ke = self.kappa, self.beta, self.kappa_e
        Ht = (rng.standard_normal((S, N, M)) + 1j * rng.standard_normal((S, N, M))) / np.sqrt(2)
        gt = (rng.standard_normal((S, N)) + 1j * rng.standard_normal((S, N))) / np.sqrt(2)
        H = np.sqrt(be * kap / (kap + 1))[None, None, :] * Hb[None] + np.sqrt(be / (kap + 1))[None, None, :] * Ht
        g = np.sqrt(self.beta_e) * (np.sqrt(ke / (ke + 1)) * gb[None, :] + np.sqrt(1 / (ke + 1)) * gt)
        HH = np.conj(np.swapaxes(H, 1, 2))
        Gi = np.linalg.inv(HH @ H)
        U = np.eye(N)[None] - H @ Gi @ HH
        W = H @ Gi
        wn2 = np.sum(np.abs(W) ** 2, axis=1)
        snr = p[None, :] / (self.s2 * wn2)
        Wn = W / np.sqrt(wn2)[:, None, :]
        leak = p[None, :] * np.abs(np.einsum('sn,snm->sm', np.conj(g), Wn)) ** 2
        an = q * np.real(np.einsum('sn,snk,sk->s', np.conj(g), U, g))
        sinr_e = leak / (an[:, None] + self.s2e)
        return np.mean(np.log2(1 + snr), 0), np.mean(np.log2(1 + sinr_e), 0)

    # ---------------- helpers ----------------
    def upa(self, rows, cols):
        xs = (np.arange(cols) - (cols - 1) / 2) * 0.5 * LAM
        ys = (np.arange(rows) - (rows - 1) / 2) * 0.5 * LAM
        X, Yg = np.meshgrid(xs, ys)
        return np.stack([X.ravel(), Yg.ravel()], axis=1)[: self.N]


def essr(Rb, Re):
    return float(np.sum(np.maximum(Rb - Re, 0)))
